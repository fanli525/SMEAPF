%% **************************************************************88
%���þ��ȷֲ���Ȩ���������б�ѩ�򷽷����ֲ�����
% 2020-05-07
%% *****************************************************************8

function [Off_position1]=L_DC(a2,Samp,YS,pop1,dalt)
zmin=min(YS);
Off_position1=[];
nObj=size(YS,2);
cN=size(a2,1);
for i=1:size(pop1,1)
    
    P1(i,:)=pop1(i).Position;
end

%%  �ҳ���òο��������ĸ���
pop2=[];
for i=1:cN
    g=Pre_DecomposedCost(Samp,YS,P1,zmin,a2(i,:)');
    [val,ind]=min(g);
    pop2=[pop2;pop1(ind)];
end
%%  ���ݷ�ɢ��׼����оֲ�����
i1=1;x1=[];      Nt=3*size(Samp,2);
for i=1:cN%
    
    gbest=pop2(i).Position;
    dg=pdist2(pop2(i).Cost',YS);
    [val,ind]=sort(dg);
    if size(Samp,1)>1*Nt
        Samp1=Samp(ind(1:Nt),:);
        YS1=YS(ind(1:Nt),:);
    else
        Samp1=Samp;
        YS1=YS;
    end
    
    L2 =@(x)Pre_DecomposedCost(Samp1,YS1,x,zmin,a2(i,:)');
     
    FE=300;
    options = optimset('Algorithm','interior-point','Display','off','MaxFunEvals',FE,'TolFun',1e-8,'GradObj','off'); % run interior-point algorithm
    L=min(Samp1);U=max(Samp1);
    if isnan(L2(gbest))==0
        try
            x= fmincon(L2,gbest,[],[],[],[],L,U,[],options);%Ϊ�𵽽��оֲ�����
        catch
        end
        
        if i1==1
            dx1=min(sqrt(sum((repmat(x,size(Samp,1),1)-Samp).^2,2)));
            if dx1>dalt
                x1(i1,:)=x;%�õ��ֲ���������
                i1=i1+1;
            end
        else
            dx=min(sqrt(sum((repmat(x,size(x1,1),1)-x1).^2,2)));
            dx1=min(sqrt(sum((repmat(x,size(Samp,1),1)-Samp).^2,2)));
            if dx>dalt & dx1>dalt
                x1(i1,:)=x;%�õ��ֲ���������
                i1=i1+1;
            end
        end
    end
end



Off_position1=[Off_position1;x1];
