%% ���òο���������Ŀ��Ԥ��
function f=preObj_Kriging(Samp,YS,x,m)
% for i=1:m
%     srgtOPT{i}=srgtsRBFSetOptions(Samp,YS(:,i), @my_rbfbuild, [],'CUB', 0.0002,1);
%     srgtSRGT{i} = srgtsRBFFit(srgtOPT{i});
% end
% for i=1:m
%     f(:,i) =my_rbfpredict(srgtSRGT{i}.RBF_Model, srgtSRGT{i}.P, x);
% end
for i=1:m
    k = oodacefit( Samp, YS(:,i) );
     f(:,i) = k.predict(x);
end
