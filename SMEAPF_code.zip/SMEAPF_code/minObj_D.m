%% ��Ŀ�����ÿһά�ȵļ�ֵ����������������
function [pop2,NFE,Samp,YS]=minObj_D(w,Samp,YS,NFE,m,CostFunction,maxNFE,dalt)
i1=0;x1=[];pop2=[];
L1 =@(x)preObj1_D(Samp,YS,x,m,w);
FE=500;
options = optimset('Algorithm','interior-point','Display','off','MaxFunEvals',FE,'TolFun',1e-8,'GradObj','off'); % run interior-point algorithm
L=min(Samp);U=max(Samp);
[val,ind]=min(YS*w);
gbest=Samp(ind,:);
if isnan(L1(gbest))==0
    x= fmincon(L1,gbest,[],[],[],[],L,U,[],options);%Ϊ�𵽽��оֲ�����
    dx=min(sqrt(sum((repmat(x,size(Samp,1),1)-Samp).^2,2)));
    if dx>dalt
        i1=i1+1;
        x1=x;%�õ��ֲ���������
    end
    
end
for i=1:i1
    if NFE<maxNFE
        pop2(i).Position = x1(i,:);
        pop2(i).Cost=CostFunction( pop2(i).Position);
        NFE=NFE+1;    Samp=[Samp;pop2(i).Position];
        YS=[ YS;   pop2(i).Cost' ];
        pop2(i).Rank = [];
        pop2(i).DominationSet = [];
        pop2(i).DominatedCount = [];
        pop2(i).NormalizedCost = [];
        pop2(i).AssociatedRef = [];
        pop2(i).DistanceToAssociatedRef = [];
        pop2(i).Isreal=1;
    end
end

