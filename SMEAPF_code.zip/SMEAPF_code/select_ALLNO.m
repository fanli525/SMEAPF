function F1=select_ALLNO(Samp,YS)
empty_individual.Position = [];
empty_individual.Cost = [];
empty_individual.Rank = [];
empty_individual.DominationSet = [];
empty_individual.DominatedCount = [];
empty_individual.NormalizedCost = [];
empty_individual.AssociatedRef = [];
empty_individual.DistanceToAssociatedRef = [];
empty_individual.Isreal= 0;
pop1 = repmat(empty_individual, size(Samp,1), 1);
for i=1:size(Samp,1)
    pop1(i).Position =Samp(i,:);
    pop1(i).Cost=YS(i,:)';
    pop1(i).Isreal= 1;
end
[popf, F] = NonDominatedSorting(pop1);
F1 = popf(F{1});