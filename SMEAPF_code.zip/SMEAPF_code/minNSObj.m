%% ��Ŀ�����ÿһά�ȵļ�ֵ����������������
 function [pop2,NFE,Samp,YS]=minNSObj(pop,VarMin,VarMax,Samp,YS,NFE,m,CostFunction,maxNFE,dalt)
i1=0;x1=[];pop2=[];

L1 =@(x)preObj1(Samp,YS,x,m);
x=MO_NSGA2(pop,L1, m,VarMin,VarMax,500)


x1=[];
for i=1:m
    dx=[];
    for j=1:size(x,1)
        dx(j)=min(sqrt(sum((repmat(x(j,:),size(Samp,1),1)-Samp).^2,2)));
    end
    [val,ind]=max(dx);
    x1=[x1;x(ind,:)];
    x(ind,:)=[];
    
end

for i=1:size(x1,1)
    dx=min(sqrt(sum((repmat(x1(i,:),size(Samp,1),1)-Samp).^2,2)));

    if dx>dalt & NFE<maxNFE
        pop2(i).Position = x1(i,:);
        pop2(i).Cost=CostFunction( pop2(i).Position);
        NFE=NFE+1;    Samp=[Samp;pop2(i).Position];
        YS=[ YS;   pop2(i).Cost' ];
        pop2(i).Rank = [];
        pop2(i).DominationSet = [];
        pop2(i).DominatedCount = [];
        pop2(i).NormalizedCost = [];
        pop2(i).AssociatedRef = [];
        pop2(i).DistanceToAssociatedRef = [];
        pop2(i).Isreal=1;
    end
end

