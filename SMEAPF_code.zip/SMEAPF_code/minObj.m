%% ��Ŀ�����ÿһά�ȵļ�ֵ����������������
 function [pop2,NFE,Samp,YS]=minObj(Samp,YS,NFE,m,CostFunction,maxNFE,dalt)
i1=0;x1=[];pop2=[];
for i=1:m
    srgtOPT{i}=srgtsRBFSetOptions(Samp,YS(:,i), @my_rbfbuild, [],'CUB', 0.0002,1);
    srgtSRGT{i} = srgtsRBFFit(srgtOPT{i});
    L1 =@(x)my_rbfpredict(srgtSRGT{i}.RBF_Model, srgtSRGT{i}.P, x);
    FE=3000;
    options = optimset('Algorithm','interior-point','Display','off','MaxFunEvals',FE,'TolFun',1e-8,'GradObj','off'); % run interior-point algorithm
    L=min(Samp);U=max(Samp);
    [val,ind]=max(YS(:,i));
    gbest=Samp(ind(1),:);
    if isnan(L1(gbest))==0
        try
            x= fmincon(L1,gbest,[],[],[],[],L,U,[],options);%Ϊ�𵽽��оֲ�����
            dx=min(sqrt(sum((repmat(x,size(Samp,1),1)-Samp).^2,2)));
            if size(x1,1)==0
                if dx>dalt
                    x1(1,:)=x;%�õ��ֲ���������
                end
            else
                dx1=min(sqrt(sum((repmat(x,size(x1,1),1)-x1).^2,2)));
                if dx>dalt & dx1>dalt
                    i1=size(x1,1)+1;
                    x1(i1,:)=x;%�õ��ֲ���������
                end
            end
        catch
        end
    end
end

for i=1:size(x1,1)
    if NFE<maxNFE
        pop2(i).Position = x1(i,:);
        pop2(i).Cost=CostFunction( pop2(i).Position);
        NFE=NFE+1;    Samp=[Samp;pop2(i).Position];
        YS=[ YS;   pop2(i).Cost' ];
        pop2(i).Rank = [];
        pop2(i).DominationSet = [];
        pop2(i).DominatedCount = [];
        pop2(i).NormalizedCost = [];
        pop2(i).AssociatedRef = [];
        pop2(i).DistanceToAssociatedRef = [];
        pop2(i).Isreal=1;
    end
end

