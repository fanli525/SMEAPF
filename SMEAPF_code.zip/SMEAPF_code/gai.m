% %%
% ������Թ���pareroƽ��
% �Է�֧�����оֲ�����
% ��ϡ�����п���ƽ��ľֲ�����
%%
% ������ܹ�����һֱ����Ѱ��ÿ��Ŀ������ŵ�


% function [PS,t1,Samp,YS,out_IGD,out_GD]=test_Pa_W1_WPU(CostFunction,PF_CostFunction,nVar, nObj,VarMin,VarMax,maxNFE,Xtrain)
% clc;clear;CostFunction=@(x)zdt2(x);PF_CostFunction=@PF_zdt2;nVar=8, nObj=2,,maxNFE=200
% VarMin=0*ones(1,nVar);VarMax=1*ones(1,nVar);nPop =80;
% load('ZDT.mat');Xtrain=ZDT{1,1};
% load('DTLZ.mat');Xtrain=DTLZ{1,1};

t0=cputime;
%% Problem Definition
VarSize = [1 nVar]; % Size of Decision Variables Matrix
%% NSGA-II Parameters
if nObj==2;nZr=30;N_PF=500; elseif nObj==3;nZr=105; N_PF=950; else;nZr=256; N_PF=950; end
[W,nZr] = UniformPoint(nZr,nObj);
Zr =W';
nZr=size(Zr,2);


nPop=size(Xtrain,1);
npoints=size(Xtrain,1);


%% Colect Parameters

params.nPop = nPop;
params.Zr = Zr;
params.nZr = size(Zr,2);
params.zmin = [];
params.zmax = [];
params.smin = [];

%% Initialization

empty_individual.Position = [];
empty_individual.Cost = [];
empty_individual.Rank = [];
empty_individual.DominationSet = [];
empty_individual.DominatedCount = [];
empty_individual.NormalizedCost = [];
empty_individual.AssociatedRef = [];
empty_individual.DistanceToAssociatedRef = [];
empty_individual.Isreal= 0;

pop = repmat(empty_individual, nPop, 1);

for i = 1:nPop
    pop(i).Position = Xtrain(i,:);
    pop(i).Cost = CostFunction(pop(i).Position);
    pop(i).Isreal=1;
    Samp(i,:)=pop(i).Position;
end
YS=[pop.Cost ]';NFE=npoints;
% Sort Population and Perform Selection
[pop, F, params] = SortAndSelectPopulation(pop, params);
[pop, d, rho] = AssociateToReferencePoint(pop, params);
dalt=min(1.0e-3,5*(1.0e-4)*sqrt(nVar)*min(VarMax-VarMin));
dlta=dalt;
%% NSGA-II Main Loop
F1 = pop(F{1});
out_IGD =zeros(1,maxNFE);
out_GD = zeros(1,maxNFE);
true_PF=PF_CostFunction(nObj,N_PF);
ys2=[F1.Cost];
out_IGD(1:NFE)=IGD( ys2',true_PF);
out_GD(1:NFE)= GD( ys2',true_PF);


it=1;

n_off=1;%ÿ�����������Ӵ���Ŀ
N_S=ceil(nZr/3);;%�ֲ������ĸ���
N_C=5;%3Ԥɸ��֧������Ŀ
N_popc=5;%2Ԥɸ��ȷ���Խ����Ŀ


while NFE<maxNFE
    Offspring=Parent_Multi_off(pop,VarMin,VarMax,n_off);
    Off_position=[];
    for i=1:length(Offspring)
        Off_position=[Off_position;Offspring{1,i}];
    end
    
    %% ***********************************************************
    Off_position1=[];Y_spar=zeros(1,nObj);X_S=[];
    if  size(F1,1)>3
%         [~,~,X_S]=Sparse_Off_F(F1,CostFunction,Samp,YS,pop,VarMin,VarMax,n_off);
        nx=size(X_S,1);
        popx = repmat(empty_individual,nx, 1);
        for i=1:nx
            popx(i).Position=X_S(i,:);
            dx=min(sqrt(sum((repmat(popx(i).Position,size(Samp,1),1)-Samp).^2,2)));
            if dx>dalt
                popx(i).Cost=CostFunction(popx(i).Position);
                popx(i).Isreal= 1;
                NFE=NFE+1;    Samp=[Samp;popx(i).Position];
                YS=[ YS;      popx(i).Cost' ];
                pop=[pop;popx(i)];
            end
        end
    end
    
    
    %% ******************************************************************
    
    pre=preObj1(Samp,YS,Off_position,nObj);
    
    Anoff=size(Off_position,1);
    popc = repmat(empty_individual,   Anoff, 1);
    
    for i = 1: Anoff
        popc(i).Position = Off_position(i,:);
        popc(i).Position = min(popc(i).Position, VarMax);
        popc(i).Position = max(popc(i).Position, VarMin);
        popc(i).Cost=   pre(i,:)' ;
    end
    
    %% ��ÿ��Ŀ��ֵ���оֲ�����
    pop6=[];
    if  NFE<maxNFE
        [pop6,NFE,Samp,YS]=minObj(Samp,YS,NFE,nObj,CostFunction,maxNFE,dalt);
    end
    if size(pop6,1)>0
        pop6=pop6';
        pop=[pop;pop6];
    end
    
    %% �ҳ���֧�����н�����֧��ƽ��
   
    
    %% ���Ӵ�����ĸ�����з�֧������
    [ pop5, F5]=N_NonDominatedSorting([pop;popc]);
     
    [pop5, TF]=N_NonDominatedSorting(pop5);
    TF1 = pop5(TF{1});
    F12=[];
    for i=1:size(TF1 ,1)
        if   TF1 (i).Isreal==0
            F12=[F12;TF1(i)];
        end
    end
    pop21=[]; ;pop2=[];ac=[];
    if size(F12,1)>0
        pop2=RV_solu2(F12,F1,N_C);
        
        for i=1:size(pop2,1)
            dx=min(sqrt(sum((repmat(pop2(i).Position,size(Samp,1),1)-Samp).^2,2)));
            if dx>dalt & NFE<maxNFE
                pop2(i).Cost=CostFunction( pop2(i).Position);
                pop2(i).Isreal=1;
                NFE=NFE+1;    Samp=[Samp;pop2(i).Position];ac=[ac;pop2(i).Cost'];
                YS=[ YS;   pop2(i).Cost' ];
                pop21=[ pop21;pop2(i)];
            end
        end
        pop2=pop21;
        pop=[pop;pop2];
        
    end
    %%  �����֧������Ŀ�Ƚ���ʱ��ѡ��ȷ���Դ�ĵ�
     F1=select_ALLNO(Samp,YS);
    
    %% ��ϡ��ƽ�����ж����Ծֲ�����
    
    
    Off_position1=[];,Y_spar=[];
    
    [Off_position1,Y_spar]=Sparse_Diver(F1,Samp,YS,[pop;popc],N_S,dalt);
    N_O=size(Off_position1,1)
    if N_O>0
        pre=preObj1(Samp,YS,Off_position1,nObj);
        pops = repmat(empty_individual, N_O, 1);
        for i = 1: N_O
            pops(i).Position = Off_position1(i,:);
            pops(i).Cost=pre(i,:)' ;
        end
        pop=[pop;pops];
    end
    
    
    
    
    pop1=[pop;popc];popc_P=[];

    pop = [pop;popc]; %#ok
    pop_P=[];
    N_pop=size(pop,1);
    for i=1:N_pop
        pop_P(i,:)=pop(i).Position;
    end
    pop_C=preObj1(Samp,YS,pop_P,nObj);
    for i=1:N_pop
        pop(i).Cost=pop_C(i,:)';
    end
    [pop, F, params] = SortAndSelectPopulation(pop, params);
    
    % Store F1
    F1=select_ALLNO(Samp,YS);
    disp(['Iteration ' num2str(it) ': Number of F1 Members = ' num2str(numel(F1))]);
    it=it+1;
    
    NFE
    
    
end


F1=select_ALLNO(Samp(1:maxNFE,:),YS(1:maxNFE,:));

for i=1:size(F1,1)
    PS(i).Position=F1(i).Position;
    PS(i).Cost=F1(i).Cost;
end

%% Results
t1=cputime-t0;
ys2=[F1.Cost];
%% ����IGD GD
out_IGD(maxNFE)=IGD( ys2',true_PF);
out_GD(maxNFE)= GD( ys2',true_PF);


% ys2=[F1.Cost];
% IGD( ys2',true_PF)
% figure
% PlotCosts(F1)

