clc;clear
%% ����ZDT

NT=[20 40 60 100];
for j=1:4

i=1;
for D=[8 20 30]
    nVar=D;
    if D<100
        npoints=NT(j);
        VarMin =0*ones(1,D);    VarMax =1*ones(1,D);

        LHS =DOELHS(npoints, nVar,5);
        LHS = ScaleVariable(LHS , [0 1]'*ones(1,nVar), [VarMin;VarMax]);
        Xtrain=LHS;
    else
        npoints=101;
        VarMin =0*ones(1,D);    VarMax =1*ones(1,D);
        LHS =DOELHS(npoints, nVar,5);
        LHS = ScaleVariable(LHS , [0 1]'*ones(1,nVar), [VarMin;VarMax]);
        Xtrain=LHS;
    end
    ZDT_D{j,i}= Xtrain;
    i=i+1;
end
end