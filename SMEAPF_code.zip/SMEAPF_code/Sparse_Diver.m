%% ***************************************************************************
% F1 ��ǰ��֧���
%Y�Ƿֲ��ľ��ȵ�
%Ytrain ��Ŀ��ռ䵱ǰ�ķ�֧���
%pop ��ǰ��Ⱥ�ĸ��� VarMin���������½�,VarMax���������Ͻ�,n_off:ÿ�Ը��� �����Ӵ���Ŀ
%   2019-10-31     �ҵ���ǰϡ������ĵ�
%% ***************************************************************************

function [Off_position1,Y_spar]=Sparse_Diver(F1,Samp,YS,pop1,N_S,dalt)
Off_position1=[];Y_spar=[];

nObj=size(YS,2);
%% ��⵱ǰ��֧��ƽ��
[ F11, F13]=sigma_NonDominatedSorting(F1);
% [ F11, F13]=NonDominatedSorting(F1);
F2 = F11(F13{1});
Ytrain=[F2.Cost]';
if size(Ytrain,1)>1
    z=min(Ytrain,[],1);
    Ytrain=Ytrain-repmat(z,size(Ytrain,1),1);
    EI=@(x)MSE(Ytrain,x);
    options = optimset('Algorithm','levenberg-marquardt'); % run interior-point algorithm
    gbest=ones(1,2*size(Ytrain,2));
    L=1.0e-6+zeros(1,2*size(Ytrain,2));U=2*ones(1,2*size(Ytrain,2));
    [x11,fx]= lsqnonlin(EI,gbest,[],[],options);
    
    D=size(Ytrain,2)-1;
    Nin=400;VarMin1=-0.01+1.0e-6+min(Ytrain);VarMax1=max(Ytrain)+0.01;
    LHS =DOELHS(Nin, D,5);
    LHS = ScaleVariable(LHS , [0 1]'*ones(1,D), [VarMin1(1:D);VarMax1(1:D)]);
    Xtrain1=LHS;
    Ytrain1=pareto_surface(Xtrain1,x11);Ytrain1=real(Ytrain1);
    Y=[Xtrain1 Ytrain1];
    Y=Y+repmat(z,size(Y,1),1);
    Ytrain=Ytrain+repmat(z,size(Ytrain,1),1);
    Y_spar=[];Yt1=Ytrain;
    
    %% �ҵ�N_S��ϡ��㴢����Y_spar
    while size(Y_spar,1)<N_S
        dg=[];
        for i=1:size(Y,1)
            dg(i)=min(pdist2(Y(i,:),Yt1));
        end
        [val,ind]=max(dg);
        Y_spar=[Y_spar;Y(ind,:)];
        Yt1=[Yt1;Y(ind,:)];
    end
    
    %% ͼ����ʾϡ�����
    figure (2);clf(2);
    if size(YS,2)==2
        scatter(Y(:,1),Y(:,2),'k.')
        hold on
        scatter(Ytrain(:,1),Ytrain(:,2),'ro')
        hold on
        scatter(Y_spar(:,1),Y_spar(:,2),'bo')
    else
        scatter3(Y(:,1),Y(:,2),Y(:,3),'k.')
        hold on
        scatter3(Ytrain(:,1),Ytrain(:,2),Ytrain(:,3),'ro')
        hold on
        scatter3(Y_spar(:,1),Y_spar(:,2),Y_spar(:,3),'bo')
    end
    
    
    drawnow
    pause(0.1)
    
    
    %% ���ж����Եľֲ�����
    %****************************************************************************************************8
    for i=1:N_S
        L1 =@(x)pre_xspar(Samp,YS,x,nObj,Y_spar(i,:));
        FE=300;
        options = optimset('Algorithm','interior-point','Display','off','MaxFunEvals',FE,'TolFun',1e-8,'GradObj','off'); % run interior-point algorithm
        L=min(Samp);U=max(Samp);
        dg=pdist2(Y_spar(i,:),[pop1.Cost]');
        [val,ind]=min(dg);
        gbest=pop1(ind).Position;
        if isnan(L1(gbest))==0
            try
                x= fmincon(L1,gbest,[],[],[],[],L,U,[],options);%Ϊ�𵽽��оֲ�����
                dx=min(sqrt(sum((repmat(x,size(Samp,1),1)-Samp).^2,2)));
                if dx>dalt
                    Off_position1=[Off_position1;x];
                end         
            catch     
            end
        end
    end
    %****************************************************************************************************8
end
    
pre=preObj1(Samp,YS,Off_position1,nObj);
hold on
if size(YS,2)==2
    scatter(pre(:,1),pre(:,2),'r*')
    
    a=[pop1.Cost]';
    hold on
    scatter(a(:,1),a(:,2),'g*')
    
    N_pop=size(pop1,1);
    
    for i=1:N_pop
        pop_P(i,:)=pop1(i).Position;
    end
    for i=1:N_pop
        a1(i,:)=zdt2( pop1(i).Position);
    end
    hold on
    scatter(a1(:,1),a1(:,2),'ko')
%     a3=zdt2( Off_position1)';
%  figure (3);clf(3);
%  scatter(a3(:,1),a3(:,2),'go')
    
    drawnow
    pause(0.1)
else
    scatter3(pre(:,1),pre(:,2),pre(:,3),'r*')
    drawnow
    pause(0.1)
end
