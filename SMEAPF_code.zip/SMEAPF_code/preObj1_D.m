%% ���òο���������Ŀ��Ԥ��
function y=preObj1_D(Samp,YS,x,m,w)
for i=1:m
    srgtOPT{i}=srgtsRBFSetOptions(Samp,YS(:,i), @my_rbfbuild, [],'CUB', 0.0002,1);
    srgtSRGT{i} = srgtsRBFFit(srgtOPT{i});
end


for i=1:m
    f(:,i) =my_rbfpredict(srgtSRGT{i}.RBF_Model, srgtSRGT{i}.P, x);
end
% y=f*w;
z=min(YS);
y=max(w'.*abs(f-z));
