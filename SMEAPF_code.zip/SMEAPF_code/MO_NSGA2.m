% �޸ĺ�NSGA2�㷨
function [PS_x,t1]=MO_NSGA2(Xtrain,CostFunction, nObj,VarMin,VarMax,maxiter)
 

t0=cputime;
[nPop,nVar]=size(Xtrain);
VarSize=[1 nVar];   % Size of Decision Variables Matrix
if nObj==2;nZr=30;N_PF=500; elseif nObj==3;nZr=105; N_PF=950; else;nZr=256; end
%% NSGA-II Parameters
pCrossover = 0.5;       % Crossover Percentage
nCrossover = 2*round(pCrossover*nPop/2); % Number of Parnets (Offsprings)
pMutation = 0.5;       % Mutation Percentage
nMutation = round(pMutation*nPop);  % Number of Mutants
mu = 0.02;     % Mutation Rate
sigma = 0.1*(VarMax-VarMin); % Mutation Step Size



%% Initialization

empty_individual.Position=[];
empty_individual.Cost=[];
empty_individual.Rank=[];
empty_individual.DominationSet=[];
empty_individual.DominatedCount=[];
empty_individual.CrowdingDistance=[];

pop=repmat(empty_individual,nPop,1);



for i = 1:nPop
    pop(i).Position = Xtrain(i,:);
    pop(i).Cost = CostFunction(pop(i).Position);
    Samp(i,:)=pop(i).Position;
end
YS=[    pop.Cost ]';NFE=nPop;


% Non-Dominated Sorting
[pop, F]=NonDominatedSorting(pop);

% Calculate Crowding Distance
pop=CalcCrowdingDistance(pop,F);

% Sort Population
[pop, F]=SortPopulation(pop);

F1 = pop(F{1});
 ys2=[F1.Cost];
 %% NSGA-II Main Loop
it=1;
while it<=maxiter
    Offspring=pro_off(pop,VarMin,VarMax);
    popc = repmat(empty_individual, nPop/2, 1);
    
    for i = 1:nPop/2
        popc(i).Position = Offspring(i,:);
        popc(i).Position = min(   popc(i).Position, VarMax);
        popc(i).Position = max(   popc(i).Position, VarMin);
        popc(i).Cost=CostFunction( popc(i).Position);

    end
    % Mutation
    popm = repmat(empty_individual, nMutation, 1);
    for k = 1:nMutation
        popm(k).Position = Offspring(k+nPop/2,:);
        popm(k).Position = max(popm(k).Position , VarMin);
        popm(k).Position = min(popm(k).Position , VarMax);
        popm(k).Cost=CostFunction( popm(k).Position);

    end
    % Merge
    pop=[pop
        popc
        popm]; %#ok
    
    % Non-Dominated Sorting
    [pop, F]=NonDominatedSorting(pop);
    
    % Calculate Crowding Distance
    pop=CalcCrowdingDistance(pop,F);
    
    % Sort Population
    pop=SortPopulation(pop);
    
    % Truncate
    pop=pop(1:nPop);
    
    % Non-Dominated Sorting
    [pop, F]=NonDominatedSorting(pop);
    
    % Calculate Crowding Distance
    pop=CalcCrowdingDistance(pop,F);
    
    % Sort Population
    [pop, F]=SortPopulation(pop);
    
    % Store F1
    F1=pop(F{1});
    
    
end 
    PS_x=[];
    
    for i = 1: size(F1,1)
        PS_x(i,:)=F1(i).Position;
    end



%% Results
t1=cputime-t0;
  

