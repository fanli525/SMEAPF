%% �ѵ��Ϊ����
function n1=sel_N(Y,Ys)
S1=[];S2=[];

for i=1:size(Y,1)
    if Y(i,1)<Ys(1)
        S1=[S1;i];
    end
    if Y(i,1)>Ys(1)
        S2=[S2;i];
    end
end

dg=pdist2(Ys,Y(S1,:));
[val,ind]=sort(dg);
n2=min(length(S1),3);

n1=S1(ind(1:n2));

dg=pdist2(Ys,Y(S2,:));
[val,ind]=sort(dg);
n2=min(length(S2),3);


n1=[n1;S2(ind(1:n2))];
