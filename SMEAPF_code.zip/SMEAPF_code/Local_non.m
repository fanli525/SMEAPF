function x1=Local_non(Samp,YS,F1,nObj,params)

cN=size(F1,1);   x1=[];
for i=1:cN%
    L2 =@(x)Dist_Zero(Samp,YS,x,nObj,params);
    i
    FE=300;
    options = optimset('Algorithm','interior-point','Display','off','MaxFunEvals',FE,'TolFun',1e-8,'GradObj','off'); % run interior-point algorithm
    L=min(Samp);U=max(Samp);
    gbest=F1(i).Position;
    if isnan(L2(gbest))==0
        try
            x= fmincon(L2,gbest,[],[],[],[],L,U,[],options);%Ϊ�𵽽��оֲ�����
            if size(x1,1)<1
                dx1=min(sqrt(sum((repmat(x,size(Samp,1),1)-Samp).^2,2)));
                if dx1>1.0e-3
                    x1=[x1;x];%�õ��ֲ���������
                end
            else
                dx=min(sqrt(sum((repmat(x,size(x1,1),1)-x1).^2,2)));
                dx1=min(sqrt(sum((repmat(x,size(Samp,1),1)-Samp).^2,2)));
                if dx>1.0e-3 & dx1>1.0e-3
                    x1=[x1;x];%�õ��ֲ���������
                end
            end
        catch
             
        end
    end
end