function y=pareto_surface(Xtrain,x)

[m,D]=size(Xtrain);
D=D+1;
e=ones(1,m);
for i=1:m
    for j=1:D-1
        e(i)=e(i)-x(j)*Xtrain(i,j)^(x(D+j));
    end
    e(i)=(e(i)/x(j+1))^(1/x(D+1+j));
end
y=e';;