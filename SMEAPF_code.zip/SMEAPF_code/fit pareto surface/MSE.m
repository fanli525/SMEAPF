function y=MSE(Ytrain,x)

[m,D]=size(Ytrain);
e=zeros(1,m);
for i=1:m
    for j=1:D
        e(i)=e(i)+x(j)*Ytrain(i,j)^(x(D+j));
    end
    e(i)=e(i)-1;
end
y=sum(e.^2);

