var searchData=
[
  ['extrinsiccorrelationmatrix',['extrinsicCorrelationMatrix',['../class_basic_gaussian_process.html#ad0dfbcfe7185eabb54cf546c5c52624b',1,'BasicGaussianProcess::extrinsicCorrelationMatrix()'],['../class_co_kriging.html#ad0dfbcfe7185eabb54cf546c5c52624b',1,'CoKriging::extrinsicCorrelationMatrix()']]]
];
