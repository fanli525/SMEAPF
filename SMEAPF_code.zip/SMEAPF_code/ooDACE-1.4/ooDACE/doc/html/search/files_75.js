var searchData=
[
  ['updatemodel_2em',['updateModel.m',['../update_model_8m.html',1,'']]],
  ['updateregression_2em',['updateRegression.m',['../update_regression_8m.html',1,'']]],
  ['updatestochasticprocess_2em',['updateStochasticProcess.m',['../update_stochastic_process_8m.html',1,'']]]
];
