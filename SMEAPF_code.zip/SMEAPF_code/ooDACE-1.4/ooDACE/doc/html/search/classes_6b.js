var searchData=
[
  ['kriging',['Kriging',['../class_kriging.html',1,'']]]
];
