var searchData=
[
  ['imse',['imse',['../class_basic_gaussian_process.html#a695047b2526ca360e328a549f0c2e3b0',1,'BasicGaussianProcess']]],
  ['imse_2em',['imse.m',['../imse_8m.html',1,'']]],
  ['intrinsiccovariancematrix',['intrinsicCovarianceMatrix',['../class_basic_gaussian_process.html#aba76ba685680ffd4c2f56389b6cbb60b',1,'BasicGaussianProcess::intrinsicCovarianceMatrix()'],['../class_co_kriging.html#aba76ba685680ffd4c2f56389b6cbb60b',1,'CoKriging::intrinsicCovarianceMatrix()']]],
  ['intrinsiccovariancematrix_2em',['intrinsicCovarianceMatrix.m',['../@_co_kriging_2intrinsic_covariance_matrix_8m.html',1,'']]],
  ['intrinsiccovariancematrix_2em',['intrinsicCovarianceMatrix.m',['../@_basic_gaussian_process_2intrinsic_covariance_matrix_8m.html',1,'']]]
];
