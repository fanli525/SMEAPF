var searchData=
[
  ['basicgaussianprocess_2em',['BasicGaussianProcess.m',['../_basic_gaussian_process_8m.html',1,'']]],
  ['blindkriging_2em',['BlindKriging.m',['../_blind_kriging_8m.html',1,'']]],
  ['buildvandermondematrix_2em',['buildVandermondeMatrix.m',['../build_vandermonde_matrix_8m.html',1,'']]]
];
