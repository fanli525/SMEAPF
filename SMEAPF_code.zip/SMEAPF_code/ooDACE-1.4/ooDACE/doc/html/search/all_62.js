var searchData=
[
  ['basicgaussianprocess',['BasicGaussianProcess',['../class_basic_gaussian_process.html',1,'BasicGaussianProcess'],['../class_basic_gaussian_process.html#a65ee2b0d1e8423e41876ac6adf524649',1,'BasicGaussianProcess::BasicGaussianProcess()']]],
  ['basicgaussianprocess_2em',['BasicGaussianProcess.m',['../_basic_gaussian_process_8m.html',1,'']]],
  ['birdfcn',['birdfcn',['../generate_datasets_8m.html#a7d58fa6ceeab514bac03687c45124506',1,'generateDatasets.m']]],
  ['blindkriging',['BlindKriging',['../class_blind_kriging.html',1,'BlindKriging'],['../class_blind_kriging.html#a682a344ea749bf70ca5fe67a65fcbb18',1,'BlindKriging::BlindKriging()']]],
  ['blindkriging_2em',['BlindKriging.m',['../_blind_kriging_8m.html',1,'']]],
  ['branin',['branin',['../generate_datasets_8m.html#a0d581561acb577d9286388b0957f856f',1,'generateDatasets.m']]],
  ['buildvandermondematrix',['buildVandermondeMatrix',['../build_vandermonde_matrix_8m.html#abd8b9b4e3d8ffebf811f92a945837ff9',1,'buildVandermondeMatrix.m']]],
  ['buildvandermondematrix_2em',['buildVandermondeMatrix.m',['../build_vandermonde_matrix_8m.html',1,'']]]
];
