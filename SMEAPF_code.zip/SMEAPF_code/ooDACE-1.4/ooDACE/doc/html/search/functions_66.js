var searchData=
[
  ['fit',['fit',['../class_basic_gaussian_process.html#a5289e400652af63e9d55ac2eed917684',1,'BasicGaussianProcess::fit()'],['../class_blind_kriging.html#a5289e400652af63e9d55ac2eed917684',1,'BlindKriging::fit()'],['../class_co_kriging.html#a5289e400652af63e9d55ac2eed917684',1,'CoKriging::fit()']]]
];
