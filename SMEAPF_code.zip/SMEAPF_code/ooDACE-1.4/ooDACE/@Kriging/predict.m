%> @file "@Kriging/predict.m"
%> @authors Ivo Couckuyt
%> @version 1.4 ($Revision$)
%> @date $LastChangedDate$
%> @date Copyright 2010-2013
%>
%> This file is part of the ooDACE toolbox
%> and you can redistribute it and/or modify it under the terms of the
%> GNU Affero General Public License version 3 as published by the
%> Free Software Foundation.  With the additional provision that a commercial
%> license must be purchased if the ooDACE toolbox is used, modified, or extended
%> in a commercial setting. For details see the included LICENSE.txt file.
%> When referring to the ooDACE toolbox please make reference to the corresponding
%> publications:
%>   - Blind Kriging: Implementation and performance analysis
%>     I. Couckuyt, A. Forrester, D. Gorissen, F. De Turck, T. Dhaene,
%>     Advances in Engineering Software,
%>     Vol. 49, pp. 1-13, July 2012.
%>   - Surrogate-based infill optimization applied to electromagnetic problems
%>     I. Couckuyt, F. Declercq, T. Dhaene, H. Rogier, L. Knockaert,
%>     International Journal of RF and Microwave Computer-Aided Engineering (RFMiCAE),
%>     Special Issue on Advances in Design Optimization of Microwave/RF Circuits and Systems,
%>     Vol. 20, No. 5, pp. 492-501, September 2010. 
%>
%> Contact : ivo.couckuyt@ugent.be - http://sumo.intec.ugent.be/?q=ooDACE
%> Signature
%>	[y sigma2] = predict(this, points)
%
% ======================================================================
%> @pre The kriging object should be fitted using a dataset (@c fit)
% ======================================================================
function [y sigma2] = predict(this, points)

	%% Constants
    [nx mx] = size(points);
	
	%% Preprocessing
	points = (points - this.inputScaling(ones(nx,1),:)) ./ this.inputScaling(2.*ones(nx,1),:);
	
    %% scaled prediction
    if nargout > 1	
        [sy sigma2] = this.predict@BasicGaussianProcess(points);
        % NOTE: unscale sigma2 here or let BasicGaussianProcess use getProcessVariance then it is scaled properly anyhow
        % NOW: sigma2 scaling is done here (cokriging is a special case
        % otherwise)
        sigma2 = this.outputScaling(2.*ones(nx,1),:).^2 .* sigma2;
    else
        sy = this.predict@BasicGaussianProcess(points);
    end
    
    %% unscale
    y = this.outputScaling(ones(nx,1),:) + this.outputScaling(2.*ones(nx,1),:) .* sy;
end
